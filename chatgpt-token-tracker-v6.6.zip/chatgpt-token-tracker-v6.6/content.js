(function () {
  console.log("ChatGPT Token Tracker v6.6 запущен!");

  if (document.getElementById("chatgpt-token-tracker-widget")) return;

  const widget = document.createElement("div");
  widget.id = "chatgpt-token-tracker-widget";
  widget.title = "Перетащите для перемещения или кликните, чтобы скопировать cURL";
  widget.style.cssText = `
    position: fixed;
    top: 12px;
    right: 136px;
    z-index: 99999;
    background: #212121;
    color: #ececec;
    padding: 8px 12px;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    border: 1px solid #333;
    display: flex;
    flex-direction: column;
    gap: 7px;
    min-width: 205px;
    cursor: move;
    user-select: none;
    transition: border-color 0.2s ease;
  `;

  chrome.storage.local.get(["widgetPosition"], (result) => {
    if (result.widgetPosition) {
      widget.style.top = result.widgetPosition.top + "px";
      widget.style.left = result.widgetPosition.left + "px";
      widget.style.right = "auto";
    }
  });

  widget.addEventListener("mouseenter", () => widget.style.borderColor = "#10a37f");
  widget.addEventListener("mouseleave", () => widget.style.borderColor = "#333");

  widget.innerHTML = `
    <div id="usage-rows" style="display:flex; flex-direction:column; gap:7px;">
      <div style="display:flex; justify-content:space-between; gap:12px; align-items:center;">
        <span style="font-weight:600;">Лимиты:</span>
        <span style="color:#b4b4b4;">Загрузка...</span>
      </div>
    </div>
  `;
  document.body.appendChild(widget);

  let isDragging = false;
  let hasDragged = false;
  let startX = 0;
  let startY = 0;
  let initialLeft = 0;
  let initialTop = 0;
  let latestUsage = null;

  widget.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    isDragging = true;
    hasDragged = false;
    const rect = widget.getBoundingClientRect();
    startX = e.clientX;
    startY = e.clientY;
    initialLeft = rect.left;
    initialTop = rect.top;
    widget.style.transition = "none";
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;
    if (Math.abs(deltaX) > 3 || Math.abs(deltaY) > 3) hasDragged = true;

    if (hasDragged) {
      const maxLeft = window.innerWidth - widget.offsetWidth;
      const maxTop = window.innerHeight - widget.offsetHeight;
      const newLeft = Math.max(0, Math.min(initialLeft + deltaX, maxLeft));
      const newTop = Math.max(0, Math.min(initialTop + deltaY, maxTop));
      widget.style.left = newLeft + "px";
      widget.style.top = newTop + "px";
      widget.style.right = "auto";
    }
  });

  document.addEventListener("mouseup", () => {
    if (!isDragging) return;
    isDragging = false;
    if (hasDragged) {
      const rect = widget.getBoundingClientRect();
      chrome.storage.local.set({
        widgetPosition: {
          top: Math.round(rect.top),
          left: Math.round(rect.left)
        }
      });
    }
  });

  widget.addEventListener("click", async (e) => {
    if (hasDragged) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }

    try {
      const response = await fetch(chrome.runtime.getURL("cURL"));
      const curlText = await response.text();
      await navigator.clipboard.writeText(curlText);
      showNotification("cURL успешно скопирован в буфер обмена!");
    } catch (err) {
      console.error("Не удалось скопировать cURL:", err);
      showNotification("Ошибка копирования cURL", true);
    }
  });

  function showNotification(text, isError = false) {
    const existing = document.getElementById("chatgpt-token-tracker-notification");
    if (existing) existing.remove();

    const notification = document.createElement("div");
    notification.id = "chatgpt-token-tracker-notification";
    notification.innerText = text;
    notification.style.cssText = `
      position: fixed;
      top: 60px;
      right: 20px;
      z-index: 100000;
      background: ${isError ? "#ef4444" : "#10a37f"};
      color: #fff;
      padding: 8px 14px;
      border-radius: 6px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      transition: opacity 0.3s ease;
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
      notification.style.opacity = "0";
      setTimeout(() => notification.remove(), 300);
    }, 2000);
  }

  function formatCountdown(windowData) {
    let seconds = null;
    if (windowData?.resetAt) {
      seconds = Math.max(0, Math.round(windowData.resetAt - Date.now() / 1000));
    } else if (Number.isFinite(windowData?.resetAfterSeconds)) {
      seconds = Math.max(0, Math.round(windowData.resetAfterSeconds));
    }
    if (!Number.isFinite(seconds)) return "";

    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (days > 0) return `сброс через ${days}д ${hours}ч`;
    if (hours > 0) return `сброс через ${hours}ч ${minutes}м`;
    return `сброс через ${Math.max(1, minutes)}м`;
  }

  function personalColor(leftPercent) {
    if (leftPercent >= 50) return "#10a37f";
    if (leftPercent >= 20) return "#eab308";
    return "#ef4444";
  }

  function corporateColor(usedPercent) {
    if (usedPercent <= 50) return "#10a37f";
    if (usedPercent <= 80) return "#eab308";
    return "#ef4444";
  }

  function makePersonalRow(label, leftPercent, subText) {
    const left = Math.max(0, Math.min(100, Number(leftPercent) || 0));
    const row = document.createElement("div");
    row.style.cssText = "display:flex; flex-direction:column; gap:3px;";
    row.innerHTML = `
      <div style="display:flex; justify-content:space-between; gap:12px; align-items:baseline;">
        <span style="font-weight:600; white-space:nowrap;">${label}</span>
        <span style="white-space:nowrap;">${Math.round(left)}% осталось</span>
      </div>
      <div style="background:#424242; border-radius:4px; overflow:hidden; height:6px; width:100%;">
        <div style="background:${personalColor(left)}; width:${left}%; height:100%; transition:width .3s ease, background .3s ease;"></div>
      </div>
      ${subText ? `<div style="color:#8e8e8e; font-size:10px; text-align:right;">${subText}</div>` : ""}
    `;
    return row;
  }

  function makeCorporateRow(monthly) {
    const limit = Number(monthly?.limit) || 0;
    const usage = Number(monthly?.usage) || 0;
    const usedPercent = limit > 0 ? Math.max(0, Math.min(100, (usage / limit) * 100)) : 0;
    const row = document.createElement("div");
    row.style.cssText = "display:flex; flex-direction:column; gap:4px;";
    row.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; gap:12px;">
        <span style="font-weight:600;">Токены:</span>
        <span>${Math.round(usage)} / ${limit} (${Math.round(usedPercent)}%)</span>
      </div>
      <div style="background:#424242; border-radius:4px; overflow:hidden; height:6px; width:100%;">
        <div style="background:${corporateColor(usedPercent)}; width:${usedPercent}%; height:100%; transition:width .3s ease, background .3s ease;"></div>
      </div>
    `;
    return row;
  }

  function renderUsage(data) {
    const container = document.getElementById("usage-rows");
    if (!container) return;
    container.innerHTML = "";

    if (!data || data.error) {
      container.innerHTML = `
        <div style="display:flex; justify-content:space-between; gap:12px;">
          <span style="font-weight:600;">Лимиты:</span>
          <span style="color:#ef4444;">Ошибка загрузки</span>
        </div>
      `;
      return;
    }

    if (data.mode === "corporate" && data.monthly) {
      // Exactly the old corporate presentation: one monthly token bar.
      container.appendChild(makeCorporateRow(data.monthly));
      return;
    }

    if (data.mode === "personal" && data.personal?.windows?.length) {
      for (const win of data.personal.windows) {
        container.appendChild(
          makePersonalRow(win.label, win.leftPercent, formatCountdown(win))
        );
      }
      return;
    }

    container.innerHTML = `
      <div style="display:flex; justify-content:space-between; gap:12px;">
        <span style="font-weight:600;">Лимиты:</span>
        <span style="color:#b4b4b4;">Нет данных</span>
      </div>
    `;
  }

  function updateUsageData() {
    chrome.runtime.sendMessage({ action: "fetchUsage" }, (response) => {
      if (chrome.runtime.lastError) {
        renderUsage({ error: chrome.runtime.lastError.message });
        return;
      }
      latestUsage = response;
      renderUsage(response);
    });
  }

  updateUsageData();
  setInterval(() => {
    if (latestUsage && !latestUsage.error) renderUsage(latestUsage);
  }, 60000);
  setInterval(updateUsageData, 5 * 60 * 1000);

  let isGenerating = false;
  let timeoutId = null;
  const observer = new MutationObserver(() => {
    const stopButton =
      document.querySelector('button[aria-label="Stop streaming"]') ||
      document.querySelector('[data-testid="stop-button"]');

    if (stopButton) {
      isGenerating = true;
    } else if (isGenerating) {
      isGenerating = false;
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(updateUsageData, 1200);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true
  });
})();
