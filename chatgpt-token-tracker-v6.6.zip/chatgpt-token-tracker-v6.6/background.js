let cachedAuth = {
  authorization: "",
  account: "",
  cookie: ""
};

chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    if (!details.url.includes("backend-api") || !details.requestHeaders) return;

    for (const header of details.requestHeaders) {
      const name = header.name.toLowerCase();
      if (name === "authorization") {
        cachedAuth.authorization = header.value || "";
      } else if (name === "chatgpt-account-id") {
        cachedAuth.account = header.value || "";
      } else if (name === "cookie") {
        cachedAuth.cookie = header.value || "";
      }
    }
  },
  { urls: ["https://chatgpt.com/backend-api/*"] },
  ["requestHeaders"]
);

async function getAccessToken() {
  try {
    const response = await fetch("https://chatgpt.com/api/auth/session", {
      method: "GET",
      credentials: "include",
      headers: { Accept: "application/json" }
    });

    if (response.ok) {
      const sessionData = await response.json();
      if (sessionData.accessToken) return `Bearer ${sessionData.accessToken}`;
    }
  } catch (err) {
    console.warn("[Token Tracker] Session token unavailable:", err);
  }

  if (cachedAuth.authorization) return cachedAuth.authorization;
  throw new Error("Access token not found");
}

async function lookupAccount(authorization) {
  const endpoints = [
    "https://chatgpt.com/backend-api/accounts/check/v4-2023-04-27",
    "https://chatgpt.com/backend-api/accounts/check/v4"
  ];

  for (const url of endpoints) {
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        headers: {
          Authorization: authorization,
          Accept: "application/json"
        }
      });

      if (!response.ok) continue;
      const data = await response.json();
      const accounts = data.accounts || {};

      // Prefer the account id captured from the currently active ChatGPT tab.
      if (cachedAuth.account) {
        return {
          id: cachedAuth.account,
          meta: accounts[cachedAuth.account] || null,
          raw: data
        };
      }

      const id = Object.keys(accounts)[0] || data.account_list?.[0]?.id;
      if (id) {
        return {
          id,
          meta: accounts[id] || data.account_list?.find((x) => x?.id === id) || null,
          raw: data
        };
      }
    } catch (err) {
      console.warn("[Token Tracker] Account lookup failed:", err);
    }
  }

  if (cachedAuth.account) return { id: cachedAuth.account, meta: null, raw: null };
  throw new Error("Account ID not found");
}

async function fetchJson(url, authorization, accountId) {
  const headers = {
    Authorization: authorization,
    Accept: "application/json"
  };
  if (accountId) headers["ChatGPT-Account-Id"] = accountId;

  const response = await fetch(url, {
    method: "GET",
    credentials: "include",
    cache: "no-store",
    headers
  });

  if (!response.ok) {
    throw new Error(`${response.status} ${response.statusText}`.trim());
  }
  return response.json();
}

async function fetchPersonalRaw(authorization, accountId) {
  // OpenAI currently exposes the same personal Usage limits through these
  // read-only endpoints. WHAM is preferred; Codex is kept as a fallback.
  const endpoints = [
    "https://chatgpt.com/backend-api/wham/usage",
    "https://chatgpt.com/backend-api/codex/usage"
  ];

  let lastError = null;
  for (const url of endpoints) {
    try {
      return await fetchJson(url, authorization, accountId);
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error("Personal usage unavailable");
}

function normalizeWindow(windowData, fallbackKey) {
  if (!windowData || typeof windowData !== "object") return null;

  const used = Number(windowData.used_percent);
  const duration = Number(windowData.limit_window_seconds);
  const resetAt = Number(windowData.reset_at);
  const resetAfter = Number(windowData.reset_after_seconds);
  if (!Number.isFinite(used)) return null;

  let key = fallbackKey;
  let label = fallbackKey === "primary" ? "Лимит" : "Доп. лимит";

  if (Number.isFinite(duration)) {
    if (duration >= 4 * 3600 && duration <= 6 * 3600) {
      key = "5h";
      label = "5 часов";
    } else if (duration >= 6 * 86400 && duration <= 8 * 86400) {
      key = "weekly";
      label = "Неделя";
    } else if (duration >= 20 * 3600 && duration <= 28 * 3600) {
      key = "daily";
      label = "Сутки";
    }
  }

  return {
    key,
    label,
    usedPercent: Math.max(0, Math.min(100, used)),
    leftPercent: Math.max(0, Math.min(100, 100 - used)),
    durationSeconds: Number.isFinite(duration) ? duration : null,
    resetAt: Number.isFinite(resetAt) ? resetAt : null,
    resetAfterSeconds: Number.isFinite(resetAfter) ? resetAfter : null
  };
}

function normalizePersonalUsage(data) {
  const rateLimit = data?.rate_limit || data?.rate_limits || {};
  const windows = [];

  const candidates = [
    [rateLimit.primary_window, "primary"],
    [rateLimit.secondary_window, "secondary"]
  ];

  for (const [raw, key] of candidates) {
    const normalized = normalizeWindow(raw, key);
    if (normalized) windows.push(normalized);
  }

  windows.sort((a, b) => {
    const order = { "5h": 0, daily: 1, weekly: 2, primary: 3, secondary: 4 };
    return (order[a.key] ?? 9) - (order[b.key] ?? 9);
  });

  return {
    planType: String(data?.plan_type || data?.planType || "").toLowerCase(),
    windows,
    credits: data?.credits || null,
    resetCredits: data?.rate_limit_reset_credits || null
  };
}

function textFromObject(value) {
  try {
    return JSON.stringify(value || {}).toLowerCase();
  } catch (_) {
    return "";
  }
}

function classifyAccount(accountMeta, personal) {
  // Explicit plan_type from the Usage API is the strongest signal.
  const personalPlans = new Set(["free", "go", "plus", "pro", "prolite", "personal"]);
  const corporatePlans = new Set(["team", "business", "enterprise", "edu", "education"]);

  if (personal?.planType) {
    if (personalPlans.has(personal.planType)) return "personal";
    if (corporatePlans.has(personal.planType)) return "corporate";
  }

  // Fall back to account metadata returned by accounts/check. The exact shape
  // changes over time, so inspect its values rather than depending on one key.
  const metaText = textFromObject(accountMeta);
  if (/enterprise|business|team|workspace|education|edu/.test(metaText)) return "corporate";
  if (/plus|prolite|\"pro\"|\"go\"|personal|free/.test(metaText)) return "personal";

  return "unknown";
}

async function fetchMonthlyUsage(authorization, accountId) {
  const url = `https://chatgpt.com/backend-api/accounts/${encodeURIComponent(accountId)}/spend-controls/current-user/monthly-usage?supports_usage_limit_modes=true`;
  const data = await fetchJson(url, authorization, accountId);

  const limit = Number(data?.effective_monthly_limit?.limit);
  const usage = Number(data?.current_month_usage);
  if (!Number.isFinite(limit) || limit <= 0 || !Number.isFinite(usage)) {
    throw new Error("Monthly usage payload has no active limit");
  }

  return { limit, usage };
}

async function loadUsage() {
  const authorization = await getAccessToken();
  const account = await lookupAccount(authorization);
  const accountId = account.id;

  let personal = null;
  let personalError = null;
  try {
    const raw = await fetchPersonalRaw(authorization, accountId);
    personal = normalizePersonalUsage(raw);
  } catch (err) {
    personalError = err;
  }

  const detectedType = classifyAccount(account.meta, personal);

  // Personal account: show only the 5-hour / weekly Usage limits.
  if (detectedType === "personal" && personal?.windows?.length) {
    return {
      mode: "personal",
      accountId,
      planType: personal.planType,
      personal
    };
  }

  // Corporate/workspace account: preserve the original v6.4 monthly-token UI.
  // Also use a valid monthly budget as a fallback signal when account metadata
  // does not expose a recognizable plan name.
  try {
    const monthly = await fetchMonthlyUsage(authorization, accountId);
    return {
      mode: "corporate",
      accountId,
      monthly
    };
  } catch (monthlyError) {
    // If metadata was inconclusive but WHAM returned real windows, treat it as
    // a personal account rather than showing an error.
    if (personal?.windows?.length) {
      return {
        mode: "personal",
        accountId,
        planType: personal.planType,
        personal
      };
    }

    const p = personalError ? `personal: ${personalError.message}; ` : "";
    throw new Error(`Usage data unavailable; ${p}monthly: ${monthlyError.message}`);
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action !== "fetchUsage") return false;

  loadUsage()
    .then((data) => sendResponse(data))
    .catch((err) => {
      console.error("[Token Tracker] Usage error:", err);
      sendResponse({ error: err.message });
    });

  return true;
});
