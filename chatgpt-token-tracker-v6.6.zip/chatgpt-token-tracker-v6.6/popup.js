document.getElementById('copyBtn').addEventListener('click', () => {
  const statusEl = document.getElementById('status');
  
  chrome.runtime.sendMessage({ action: "get Curl" }, (response) => {
    if (response && response.curl) {
      navigator.clipboard.writeText(response.curl).then(() => {
        statusEl.style.color = '#4ade80';
        statusEl.textContent = 'Скопировано!';
        setTimeout(() => { statusEl.textContent = ''; }, 2000);
      });
    } else {
      statusEl.style.color = '#f87171';
      statusEl.textContent = response.error || 'Обновите чат!';
    }
  });
});